#!/usr/bin/perl

##
## Multi FASTA wrapper for the AMPA.pl core script
##
## If few words, just read a fasta file and for each sequence 
## invoke the core ampa script for that sequence
##
## At the end create a single result file (result.txt or other if specified)
## containing all the produced output 
##

use strict;
use Bio::SeqIO;


my $input_file;
my $result_file = "result.txt";
my $target_cmd = '.single.fa.tmp';

my $cl = join( " ", @ARGV);


##
## Print the usage help 
## 
if (($cl=~/-h/) || ($cl=~/-H/) || ($cl=~/-help/) || ($cl=~/-HELP/) ) {
        # print usage 
        print "Usage: multi-AMPA.pl -in=<input fasta file> [other options]\n";
        print "\n";
        print "Available options:\n";
        print "-in      Fasta sequence input file\n";
        print "-t       Threshold value (default: 7)\n";
        print "-w       Window size value (default: 0.225)\n";
        print "-rf      File name for the result file (default 'result.txt')\n";
        print "-noplot  Skip plot creation step\n";
        print "-help    This help information\n";
        print "\n";
        print "Please note: use the '=' character the separate option name by its value.\n";
        exit 1;
}



##
## option '-in': input file name
##
if ( ($cl=~/-in=\s*(\S+)/)) { 
        $input_file = $1;
}
else {
	print "No input has been specified. Run the script using the \"-in=<file>\" command line option.\n\n";
	exit 1;	
}

# option '-w': window size
if ( ($cl =~ /-w=\s*(\S+)/)) { 
	$target_cmd .= " -w=$1"; 
}

# option '-t': threshold value
if ( ($cl =~ /-t=\s*(\S+)/)) { 
	$target_cmd .= " -t=$1"; 
}

# option '-rf': output result file
if ( ($cl =~ /-rf=\s*(\S+)/)) { 
        $result_file = $1;
}


## 
## Read the complete multi-fasta file 
## 
my $in  = Bio::SeqIO->new(-file => $input_file,-format => 'Fasta');

##
## 
open(RESULT, ">$result_file");

## 
## Iterate over the complete multi-fasta file 
## for each sequence save it in a file named '.single.fa.tmp'
## invoke the AMPA script using that file name 
## 
my $count=0;
my $this_seq;
while ( $this_seq = $in->next_seq() ) {
	$count = $count+1;
	
	open(TMP, ">.single.fa.tmp") or die('Cannot sequence create temporary file');
	print TMP 
		">", $this_seq->display_id(), "\n",
		$this_seq->seq(), "\n";
	close(TMP);
	
	my $opt = "$target_cmd -rf=result.$count.txt -df=data.$count.txt " ;
	if ( ($cl =~ /-noplot/)) { 
		$opt .= " -noplot"; 
	}
	else {
		$opt .= " -gf=plot.$count.png "; 
	}
	
	## 
	## Invoke the ampa script and check the returned error code
	## 
	`perl ./AMPA.pl $opt`;
	if ( $? != 0 )
	{
	  print "Cannot run the AMPA.pl script. Returned error: $!\n";
	  exit 2;
	}
	
	
	## 
	## Appending the result to the single one 
	## 
  	print RESULT "Protein: ", $this_seq->display_id(), "\n";

	open( FILE, "result.$count.txt") or die "Cannot read result.$count.txt file. Cause: $!\n";
	while (my $line = <FILE>) {
  		print RESULT $line;
	} 
	print RESULT "\n";
	close FILE;
	unlink("result.$count.txt");
	unlink("data.$count.txt");
	unlink(".single.fa.tmp");
	
}

close RESULT;
